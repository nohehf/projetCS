test_v12.m à servi à valider la fonction power_v12

Le module puissance_itérée.m est une version modifié de la partie 1 pour 
vérifié le comportement de cette algorithme si on utilise une matrice et non
pas un seul vecteur pour le paramètre V.

Pour valider les algorithmes de subspace iteration, nous avon utilisé 
test_subspace_iter.m 

Le module test_repartition.m a été utilisé pour tracer les histogrammes de 
repartition de valeurs propres des différents types de matrice pour la Q14
